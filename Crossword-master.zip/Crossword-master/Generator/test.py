#!/usr/bin/python
# -*- coding: utf-8 -*-

import mot_tri

print mot_tri.mot[4][10]
